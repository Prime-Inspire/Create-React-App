import { render } from "@testing-library/react";
import App from "./App";

test("Outputs the H1 Tag", () => {
    const {getByText} = render(<App />);
    const h1 = getByText(/Welcome to React Testing Library/);
    expect(h1).toHaveTextContent("Welcome to React Testing Library");
})