import { timesFour } from "./function";

test("Multiples of four", () => {
    expect( timesFour(4) ).toBe(16);
})