export function timesFour(a) {
    return a * 4;
}